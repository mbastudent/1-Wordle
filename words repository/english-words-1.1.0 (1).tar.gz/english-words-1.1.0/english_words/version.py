"""Contains name, version, description."""

NAME = 'english-words'
VERSION = '1.1.0'
DESCRIPTION = "contains sets of English words"
